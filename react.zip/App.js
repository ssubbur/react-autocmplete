import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';
import Users from './components/users.component';
import Projects from './components/projects.component';
import AddTask from './components/add-task.component';
import ViewTask from './components/view-task.component';
import 'bootstrap/dist/css/bootstrap.min.css';

class App extends Component {
  render() {
    return (
      <Router>
        <div className="container">
          <h2> Project Manager</h2>
          <nav className="navbar navbar-expand-lg navbar-light bg-light">
            <div className="collapse navbar-collapse" id="navbarNav">
              <ul className="navbar-nav mr-auto">
                <li className="navbar-item">
                  <Link to="/" className="nav-link "> Add User</Link>
                </li>
                <li className="navbar-item">
                  <Link to="/projects" className="nav-link"> Add Project</Link>
                </li>
                <li className="navbar-item">
                  <Link to="/addtask" className="nav-link"> Add Task</Link>
                </li>
                <li className="navbar-item">
                  <Link to="/viewtask/1" className="nav-link"> View Task</Link>
                </li>
              </ul>
            </div>
          </nav>
          <Route path="/" exact component={Users}></Route>
          <Route path="/users" exact component={Users}></Route>
          <Route path="/projects" component={Projects}></Route>
          <Route path="/addtask" component={AddTask}></Route>
          <Route path="/viewtask/:id" component={ViewTask}></Route>
        </div>
      </Router>


    );
  }
}

export default App;
