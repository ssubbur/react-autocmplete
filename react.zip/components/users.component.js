import React, { Component } from 'react';

export default class Users extends Component {
    constructor(props) {
        super(props);

        this.onChangeFirstName = this.onChangeFirstName.bind(this);
        this.onChangeLastName = this.onChangeLastName.bind(this);
        this.onChangeEmpId = this.onChangeEmpId.bind(this);
        this.onSubmit = this.onSubmit.bind(this);
        this.reset = this.reset.bind(this);

        this.state = {
            firstName: '',
            lastName: '',
            empId: '',
            btnCaption: 'Add User'
        }
    }
    onChangeFirstName(e) {
        this.setState({ firstName: e.target.value });
    }
    onChangeLastName(e) {
        this.setState({ lastName: e.target.value });
    }
    onChangeEmpId(e) {
        this.setState({ empId: e.target.value });
    }
    onSubmit(e) {
        e.preventDefault();

        console.log(`Form submitted:`);
        console.log(`First Name: ${this.state.firstName}`);
        console.log(`Last Name: ${this.state.lastName}`);
        console.log(`Emp Id: ${this.state.empId}`);

        this.setState({
            id:'',
            firstName: '',
            lastName: '',
            empId: ''
        });
    }
    reset() {
        this.setState({
            firstName: '',
            lastName: '',
            empId: '',
            btnCaption: 'Add User'
        });
    }
    render() {
        return (
            <div style={{ marginTop: 20 }}>
                <h2>{this.state.btnCaption} </h2>
                <form onSubmit={this.onSubmit}>
                    <div className="form-group row">
                        <label className="col-sm-2 col-form-label">First Name:</label>
                        <div className="col-sm-4">
                            <input type="text"
                                className="form-control"
                                value={this.state.firstName}
                                onChange={this.onChangeFirstName}
                                id="firstName"
                            />
                        </div>
                    </div>
                    <div className="form-group row">
                        <label className="col-sm-2 col-form-label">Last Name:</label>
                        <div className="col-sm-4">
                            <input type="text"
                                className="form-control"
                                value={this.state.lastName}
                                onChange={this.onChangeLastName}
                                id="lastName"
                            />
                        </div>
                    </div>
                    <div className="form-group row">
                        <label className="col-sm-2 col-form-label">Employee Id: </label>
                        <div className="col-sm-4">
                            <input type="text"
                                className="form-control"
                                value={this.state.empId}
                                onChange={this.onChangeEmpId}
                                id="empId"
                            />
                        </div>
                    </div>
                    <div className="form-group row">
                        
                        <div className="col-sm-2">
                            <input type="submit" value={this.state.btnCaption} className="btn btn-primary" />
                        </div>
                        <div className="col-sm-1">
                            <input type="reset" value="Reset" className="btn btn-primary" onClick={this.reset} />
                        </div>

                    </div>
                </form>
            </div>
        );
    }
}
