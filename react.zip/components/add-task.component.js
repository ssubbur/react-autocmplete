import React, { Component } from 'react';

export default class AddTask extends Component{
    render(){
        return ( 
            <div>
                <h1> Add task component</h1>
            </div>
        );
    }
}