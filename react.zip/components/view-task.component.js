import React, { Component } from 'react';

export default class ViewTask extends Component{
    render(){
        return ( 
            <div>
                <h1> View task component</h1>
            </div>
        );
    }
}